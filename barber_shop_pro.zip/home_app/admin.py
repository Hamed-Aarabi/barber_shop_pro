from django.contrib import admin
from .models import HomeInfo

admin.site.register(HomeInfo)
