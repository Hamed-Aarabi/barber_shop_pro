from django.apps import AppConfig


class AppointmentAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'appointment_app'
