from django.contrib import admin
from .models import *


admin.site.register(AboutUs)
admin.site.register(Barber)
admin.site.register(SocialMedia)