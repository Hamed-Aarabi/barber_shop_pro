from django.contrib import admin
from .models import *

admin.site.register(Contactus)
admin.site.register(SocialMediaContact)
admin.site.register(WorkHour)
admin.site.register(OurBranch)
